# PRODUKTDATENBLATT · BUCH-01 / BUCH-02
## „Der Homepage-Standard"

| | |
|---|---|
| Artikelnummer | BUCH-01 (Print) · BUCH-02 (E-Book) |
| Preis | **39,90 € brutto** (Print) · **29,90 € brutto** (E-Book) |
| Umsatzsteuer | 7 % (beide Formate) |
| Preisbindung | **Ja — BuchPrG** |
| Zahlungsbedingung | **Z5** — Abwicklung über BoD und Buchhandel |
| Vertrieb | Print-on-Demand, Buchhandel, Onlinehändler |
| Freigabestatus | 🔴 fünf Publikationsblocker offen |

---

## 1. Funktion im Portfolio

Das Buch verkauft keine Websprints. Es macht den **Mechanismus glaubwürdig**.

Ein Standard, der nur im Verkaufsgespräch existiert, ist eine Behauptung. Ein Standard mit ISBN, im Buchhandel gelistet, ist eine Referenz. Diese Differenz ist der Grund, warum 3.500 € statt 900 € durchsetzbar sind.

**Zweite Funktion:** geografische Entkopplung. Der Kammerbezirk gibt 300–370 Fälle pro Jahr her. Buch und Workbook kennen diese Grenze nicht.

---

## 2. Produktdaten

| | |
|---|---|
| Umfang | ca. 48.000 Wörter, ca. 166 Seiten |
| Struktur | 14 Kapitel, 3 Anhänge |
| Inhalt | Auditsystem mit 100 Punkten in 8 Kategorien, Branchenklassen K1–K6, Punktabzugstabellen, rechtliche Grundlagen |
| Formate | Softcover (BoD), E-Book (EPUB/PDF) |
| ISBN | erforderlich, noch zu beantragen |

---

## 3. 🔴 Buchpreisbindung — verbindliche Regeln für die Vermarktung

Das Buchpreisbindungsgesetz gilt für Printbücher **und** E-Books.

| Vermarktungsidee | Zulässig |
|---|---|
| Buch als kostenloser Lead-Magnet | ❌ sehr wahrscheinlich unzulässig |
| „Gratis, nur Versand zahlen" | ❌ unzulässig |
| Buch im Rabatt-Bundle mit Workbook | ❌ unzulässig, soweit der Buchanteil verbilligt wird |
| Kaufpreis auf einen Websprint anrechnen | ❌ faktischer Rabatt |
| Verkauf zum vollen Ladenpreis an Innungen, Kammern, Steuerberater | ✅ |
| Einzelne Kapitel als eigenständiges kostenloses PDF ohne ISBN | ✅ |
| Belegexemplare an Presse und Rezensenten | ✅ |
| Signierte Exemplare bei Vorträgen zum Ladenpreis | ✅ |

**Konsequenz:** Der Lead-Magnet ist der kostenlose 100-Punkte-Check, **nicht das Buch**. Wer den Funnel andersherum baut, riskiert Abmahnungen durch Mitbewerber und den Börsenverein.

⚠️ Dies ist eine Risikoauflistung, keine Rechtsberatung. Gehört in dieselbe anwaltliche Prüfung wie die Garantietexte.

---

## 4. Publikationsblocker

| ID | Blocker | Wirkung |
|---|---|---|
| B1 | Branchenklassen K1–K6 im Buch beschrieben, in KAS nicht implementiert | Das Buch beschreibt ein Produkt, das der Leser nicht kaufen kann |
| B2 | Score-Schwellen Frontend 85/70/50/30 ≠ Backend 95/85/70/50 | Leser rechnet nach und bekommt in der Software ein anderes Ergebnis |
| B3 | Punktabzugstabellen plausibel konstruiert, nicht aus `audit_criteria.py` extrahiert | Buch und Software widersprechen sich in Zahlen |
| B4 | PageSpeed-Key fehlt, 18 von 100 Punkten nicht erhebbar | Der Standard ist im eigenen Werkzeug nicht vollständig messbar |
| B5 | Neun Rechtsaussagen ohne anwaltliche Prüfung | Haftung, Abmahnrisiko |

**B2 und B3 sind die gefährlichsten.** Sie erzeugen zwei Wahrheiten. Ein Leser, der im Buch „ab 85 Punkten abnahmefähig" liest und in der Anwendung „ab 95" sieht, verliert nicht das Vertrauen in die Software, sondern in den Standard — und damit in den Preis.

**Reihenfolge der Behebung:** B3 → B2 → B4 → B1 → B5 → BoD-Upload.

**Grundregel für B3:** Das Manuskript muss aus der Software erzeugt werden, nicht neben ihr. Ein Exportskript, das `audit_criteria.py` in Markdown-Tabellen überführt, ist dauerhaft nötig — sonst laufen Buch und Software beim nächsten Kriterien-Update wieder auseinander.

---

## 5. Vertriebswege

| Weg | Rolle |
|---|---|
| BoD → Buchhandel, Onlinehändler | Hauptvertrieb, keine eigene Abwicklung |
| Eigene Landingpage (separate Netlify-Site) | Verweis auf Buchhandel, Leseprobe, Autorenprofil |
| Vorträge bei Kammern und Innungen | Verkauf zum Ladenpreis vor Ort |
| Steuerberater und Unternehmensberater | Weitergabe an Mandanten zum Ladenpreis |

**Bewusste Entscheidung: Das Buch wird nicht über KAS verkauft.** Rechnungsstellung, lückenlose Nummernkreise, Widerrufsbelehrung und 7-%-Behandlung stehen in keinem Verhältnis zum Deckungsbeitrag. BoD übernimmt das.

---

## 6. Textbaustein für Kundenkommunikation

> **Der Homepage-Standard**
>
> Der erste dokumentierte Qualitätsmaßstab für die Websites von Handwerks- und Baubetrieben: 100 Punkte, 8 Kategorien, nachvollziehbar bewertet. Das Buch erklärt jedes Kriterium, seinen Punktwert und den Weg zur Erfüllung.
>
> 166 Seiten, Softcover, 39,90 €. Erhältlich im Buchhandel und überall online.

---

## 7. Offene Punkte

| # | Punkt | Verantwortung |
|---|---|---|
| 1 | 🔴 B3: Exportskript `audit_criteria.py` → Manuskripttabellen | Technik |
| 2 | 🔴 B2: eine zentrale Schwellendefinition, Frontend liest vom Backend | Technik |
| 3 | 🔴 B4: PageSpeed-Key auf Render setzen | Technik |
| 4 | 🔴 B1: K1–K6 implementieren **oder** aus dem Manuskript streichen | Geschäftsführung |
| 5 | 🔴 B5 und Buchpreisbindung anwaltlich prüfen | Recht |
| 6 | ISBN beantragen, BoD-Konto einrichten | Verlag |
| 7 | Titelgestaltung — Manuel | Gestaltung |
| 8 | Preisentscheidung 39,90 € oder 49,00 € | Geschäftsführung |
